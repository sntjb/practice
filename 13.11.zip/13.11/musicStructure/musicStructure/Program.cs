﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace musicStructure
{
    class Program
    {
        static void Main()
        {
            Console.Write("Введите путь к MP3-файлу: ");
            string filePath = Console.ReadLine();

            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл не существует.");
                return;
            }

            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    // Пропускаем ID3v2 теги если есть
                    byte[] header = new byte[10];
                    fs.Read(header, 0, 10);

                    if (header[0] == 0x49 && header[1] == 0x44 && header[2] == 0x33) // "ID3"
                    {
                        int id3Size = ((header[6] & 0x7F) << 21) | ((header[7] & 0x7F) << 14) |
                                     ((header[8] & 0x7F) << 7) | (header[9] & 0x7F);
                        fs.Seek(id3Size, SeekOrigin.Current);
                    }
                    else
                    {
                        fs.Seek(0, SeekOrigin.Begin);
                    }

                    // Ищем MP3 frame sync
                    byte[] buffer = new byte[4];
                    while (fs.Position < fs.Length - 4)
                    {
                        fs.Read(buffer, 0, 4);

                        if (buffer[0] == 0xFF && (buffer[1] & 0xE0) == 0xE0) // Sync bits
                        {
                            int version = (buffer[1] & 0x18) >> 3;
                            int layer = (buffer[1] & 0x06) >> 1;
                            int bitrateIndex = (buffer[2] & 0xF0) - 1 >> 4;
                            int sampleRateIndex = (buffer[2] & 0x0C) >> 2;

                            int bitrate = GetBitrate(version, layer, bitrateIndex);
                            int sampleRate = GetSampleRate(version, sampleRateIndex);

                            if (bitrate > 0 && sampleRate > 0)
                            {
                                FileInfo fileInfo = new FileInfo(filePath);
                                double duration = (fileInfo.Length * 8.0) / (bitrate * 1000.0);
                                TimeSpan time = TimeSpan.FromSeconds(duration);

                                Console.WriteLine($"Файл: {Path.GetFileName(filePath)}");
                                Console.WriteLine($"версия: {version}");
                                Console.WriteLine($"слой: {layer}");
                                Console.WriteLine($"битрейт индекс: {bitrateIndex}");
                                Console.WriteLine($"семпл рейт индекс: {sampleRateIndex}");
                                Console.WriteLine($"Битрейт: {bitrate} kbps");
                                Console.WriteLine($"Частота: {sampleRate} Гц");
                                Console.WriteLine($"Длительность: {time.Minutes}:{time.Seconds:D2}");
                                return;
                            }
                        }
                        fs.Seek(-3, SeekOrigin.Current);
                    }

                    Console.WriteLine("Не удалось найти MP3 frame.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            Console.ReadKey();
        }

        static int GetBitrate(int version, int layer, int index)
        {
            if (index == 0 || index == 15) return 0;

            int[,,] bitrates = {
            { // MPEG Version 2.5
                { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 0 }, // Layer I
                { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 },      // Layer II
                { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 }       // Layer III
            },
            { // Reserved
                { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
                { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
            },
            { // MPEG Version 2
                { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 0 },
                { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 },
                { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 }
            },
            { // MPEG Version 1
                { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 0 },
                { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 0 },
                { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0 }
            }
        };

            return bitrates[version, layer, index];
        }

        static int GetSampleRate(int version, int index)
        {
            int[,] sampleRates = {
            { 11025, 12000, 8000, 0 },  // MPEG Version 2.5
            { 0, 0, 0, 0 },             // Reserved
            { 22050, 24000, 16000, 0 }, // MPEG Version 2
            { 44100, 48000, 32000, 0 }  // MPEG Version 1
        };

            return sampleRates[version, index];
        }
    }
}
