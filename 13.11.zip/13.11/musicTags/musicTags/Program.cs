﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace musicTags
{
    class Program
    {
        static void Main()
        {
            Console.Write("Введите путь к MP3-файлу: ");
            string filePath = Console.ReadLine();

            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл не существует.");
                return;
            }

            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    if (fs.Length >= 128)
                    {
                        fs.Seek(-128, SeekOrigin.End);
                        byte[] tagBuffer = new byte[128];
                        fs.Read(tagBuffer, 0, 128);

                        if (Encoding.ASCII.GetString(tagBuffer, 0, 3) == "TAG")
                        {
                            string title = Encoding.ASCII.GetString(tagBuffer, 3, 30).TrimEnd('\0');
                            string artist = Encoding.ASCII.GetString(tagBuffer, 33, 30).TrimEnd('\0');
                            string album = Encoding.ASCII.GetString(tagBuffer, 63, 30).TrimEnd('\0');
                            string year = Encoding.ASCII.GetString(tagBuffer, 93, 4).TrimEnd('\0');
                            byte genre = tagBuffer[127];

                            Console.WriteLine($"Файл: {Path.GetFileName(filePath)}");
                            Console.WriteLine($"Название: {title}");
                            Console.WriteLine($"Исполнитель: {artist}");
                            Console.WriteLine($"Альбом: {album}");
                            Console.WriteLine($"Год: {year}");
                            Console.WriteLine($"Жанр: {GetGenreName(genre)}");
                        }
                        else
                        {
                            Console.WriteLine("Теги ID3v1 не найдены.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Файл слишком мал для содержания тегов.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            Console.ReadLine();
        }

        static string GetGenreName(byte genreIndex)
        {
            string[] genres = {
            "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop",
            "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock",
            "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack",
            "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance",
            "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
            "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop",
            "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic",
            "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40",
            "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave",
            "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk",
            "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock",
            "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass",
            "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock",
            "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech",
            "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus",
            "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad",
            "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella",
            "Euro-House", "Dance Hall", "Downtempo"
        };

            return genreIndex < genres.Length ? genres[genreIndex] : "Unknown";
        }
    }
}
