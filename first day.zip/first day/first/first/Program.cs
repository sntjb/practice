﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Генератор названия группы");

        Console.Write("Введите прилагательное, наиболее подробно вас описывающее: ");
        string adjective = Console.ReadLine();

        Console.Write("Введите название вашей любимой вещи: ");
        string favoriteThing = Console.ReadLine();

        string bandName = $"{Capitalize(adjective)} {Capitalize(favoriteThing)}";
        Console.WriteLine($"\nВаша группа: \"{bandName}\"");
    }

    static string Capitalize(string word)
    {
        return char.ToUpper(word[0]) + word.Substring(1).ToLower();
    }
}