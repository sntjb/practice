﻿using System;
using System.Linq;

namespace CaesarCipher
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Добро пожаловать в шифровальщик!");

            while (true)
            {
                try
                {
                    Console.WriteLine();
                    Console.WriteLine("Напечатайте «зашифровать» для зашифровки сообщения. Или «расшифровать» для расшифровки:");
                    string command = Console.ReadLine()?.ToLower().Trim();

                    if (string.IsNullOrWhiteSpace(command))
                    {
                        Console.WriteLine("Ошибка: Команда не может быть пустой.");
                        continue;
                    }

                    switch (command)
                    {
                        case "зашифровать":
                            EncryptMessage();
                            break;
                        case "расшифровать":
                            DecryptMessage();
                            break;
                        case "выйти":
                            Console.WriteLine("До свидания!");
                            return;
                        default:
                            Console.WriteLine("Ошибка: Неизвестная команда. Используйте «зашифровать», «расшифровать» или «выйти».");
                            break;
                    }

                    // Запрос на продолжение
                    Console.WriteLine();
                    Console.WriteLine("Напечатайте «сначала» чтобы вернутся в меню. Или «выйти» для завершения программы:");
                    string continueCommand = Console.ReadLine()?.ToLower().Trim();

                    if (continueCommand == "выйти")
                    {
                        Console.WriteLine("До свидания!");
                        return;
                    }
                    else if (continueCommand != "сначала")
                    {
                        Console.WriteLine("Неизвестная команда, возвращаемся в меню...");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }
            }
        }

        static void EncryptMessage()
        {
            Console.WriteLine("Введите сообщение для шифровки без пробелов английскими буквами:");
            string message = Console.ReadLine()?.Trim();

            // Проверка сообщения
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Сообщение не может быть пустым.");
            }

            if (message.Contains(" "))
            {
                throw new ArgumentException("Сообщение не должно содержать пробелов.");
            }

            if (!message.All(char.IsLetter) || !message.All(c => IsEnglishLetter(c)))
            {
                throw new ArgumentException("Сообщение должно содержать только английские буквы.");
            }

            int shift = GetValidShift();
            string encrypted = CaesarCipher(message, shift, true);

            Console.WriteLine($"Зашифрованный результат: {encrypted}");
        }

        static void DecryptMessage()
        {
            Console.WriteLine("Введите сообщение для расшифровки:");
            string message = Console.ReadLine()?.Trim();

            // Проверка сообщения
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentException("Сообщение не может быть пустым.");
            }

            if (message.Contains(" "))
            {
                throw new ArgumentException("Сообщение не должно содержать пробелов.");
            }

            if (!message.All(char.IsLetter) || !message.All(c => IsEnglishLetter(c)))
            {
                throw new ArgumentException("Сообщение должно содержать только английские буквы.");
            }

            int shift = GetValidShift();
            string decrypted = CaesarCipher(message, shift, false);

            Console.WriteLine($"Расшифрованный результат: {decrypted}");
        }

        static int GetValidShift()
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Введите сдвиг:");
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        Console.WriteLine("Ошибка: Сдвиг не может быть пустым.");
                        continue;
                    }

                    if (!input.All(char.IsDigit))
                    {
                        Console.WriteLine("Ошибка: Сдвиг должен быть целым числом.");
                        continue;
                    }

                    int shift = int.Parse(input);

                    if (shift <= 0)
                    {
                        Console.WriteLine("Ошибка: Сдвиг должен быть положительным числом.");
                        continue;
                    }

                    if (shift > 25)
                    {
                        Console.WriteLine("Внимание: Сдвиг больше 25 будет эквивалентен сдвигу по модулю 26.");
                    }

                    return shift;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка: Сдвиг должен быть целым числом.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка: Слишком большой сдвиг.");
                }
            }
        }

        static string CaesarCipher(string text, int shift, bool encrypt)
        {
            if (!encrypt)
            {
                shift = -shift;
            }

            char[] result = new char[text.Length];

            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];

                if (char.IsLower(c))
                {
                    result[i] = (char)(((c - 'a' + shift) % 26 + 26) % 26 + 'a');
                }
                else if (char.IsUpper(c))
                {
                    result[i] = (char)(((c - 'A' + shift) % 26 + 26) % 26 + 'A');
                }
                else
                {
                    result[i] = c;
                }
            }

            return new string(result);
        }

        static bool IsEnglishLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        }
    }
}