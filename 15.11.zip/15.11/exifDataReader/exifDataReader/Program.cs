﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace exifDataReader
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.WriteLine("=== Чтение EXIF-метаданных изображений ===");
                Console.Write("Введите путь к изображению (.jpg, .jpeg, .png) или 'q' для выхода: ");

                string filePath = Console.ReadLine()?.Trim(' ', '"');

                if (filePath?.ToLower() == "q")
                    break;

                if (string.IsNullOrWhiteSpace(filePath))
                {
                    Console.WriteLine("Ошибка: Путь не может быть пустым.\n");
                    continue;
                }

                try
                {
                    ReadExifMetadata(filePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}\n");
                }

                Console.WriteLine();
            }
        }

        static void ReadExifMetadata(string filePath)
        {
            // Проверка существования файла
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"Файл '{filePath}' не найден.");
            }

            // Проверка расширения файла
            string extension = Path.GetExtension(filePath).ToLower();
            if (extension != ".jpg" && extension != ".jpeg" && extension != ".png")
            {
                throw new ArgumentException("Поддерживаются только файлы .jpg, .jpeg и .png");
            }

            using (System.Drawing.Image img = System.Drawing.Image.FromFile(filePath))
            {
                Console.WriteLine($"\nФайл: {Path.GetFileName(filePath)}");
                Console.WriteLine(new string('-', 40));

                // Проверяем наличие EXIF-данных
                if (!HasExifData(img))
                {
                    Console.WriteLine("EXIF-метаданные отсутствуют в изображении.");
                    return;
                }

                // Получаем все свойства
                PropertyItem[] properties = img.PropertyItems;

                // Извлекаем нужные метаданные
                ExtractAndDisplayMetadata(img, properties);
            }
        }

        private static void ExtractAndDisplayMetadat(System.Drawing.Image img, PropertyItem[] properties)
        {
            throw new NotImplementedException();
        }

        static bool HasExifData(System.Drawing.Image image)
        {
            try
            {
                // Проверяем наличие хотя бы одного EXIF-свойства
                return image.PropertyIdList != null && image.PropertyIdList.Length > 0;
            }
            catch
            {
                return false;
            }
        }

        static void ExtractAndDisplayMetadata(System.Drawing.Image image, PropertyItem[] properties)
        {
            bool hasAnyData = false;

            // 1. Дата съёмки
            string dateTaken = GetExifPropertyString(properties, 0x9003); // DateTimeOriginal
            if (!string.IsNullOrEmpty(dateTaken))
            {
                Console.WriteLine($"Дата съёмки: {FormatExifDateTime(dateTaken)}");
                hasAnyData = true;
            }

            // 2. Модель камеры
            string cameraModel = GetExifPropertyString(properties, 0x0110); // Model
            if (!string.IsNullOrEmpty(cameraModel))
            {
                Console.WriteLine($"Камера: {cameraModel.Trim()}");
                hasAnyData = true;
            }

            // 3. Производитель камеры
            string cameraMake = GetExifPropertyString(properties, 0x010F); // Make
            if (!string.IsNullOrEmpty(cameraMake))
            {
                if (string.IsNullOrEmpty(cameraModel))
                {
                    Console.WriteLine($"Камера: {cameraMake.Trim()}");
                }
                else if (!cameraModel.Contains(cameraMake.Trim()))
                {
                    Console.WriteLine($"Камера: {cameraMake.Trim()} {cameraModel.Trim()}");
                }
                hasAnyData = true;
            }

            // 4. Разрешение изображения
            Console.WriteLine($"Разрешение: {image.Width}x{image.Height}");

            // 5. Ориентация
            string orientation = GetOrientation(properties, image.Width, image.Height);
            Console.WriteLine($"Ориентация: {orientation}");
            hasAnyData = true;

            // Если не нашли основных EXIF-данных, но есть другие свойства
            if (!hasAnyData)
            {
                Console.WriteLine("Основные EXIF-метаданные отсутствуют, но обнаружены другие свойства.");
                Console.WriteLine($"Обнаружено EXIF-свойств: {properties.Length}");
            }

            // Дополнительная информация (опционально)
            DisplayAdditionalInfo(properties);
        }

        static string GetExifPropertyString(PropertyItem[] properties, int propertyId)
        {
            foreach (var prop in properties)
            {
                if (prop.Id == propertyId)
                {
                    return Encoding.UTF8.GetString(prop.Value).Trim('\0');
                }
            }
            return null;
        }

        static string FormatExifDateTime(string exifDateTime)
        {
            try
            {
                // EXIF формат: "YYYY:MM:DD HH:MM:SS"
                if (exifDateTime.Length >= 19)
                {
                    string datePart = exifDateTime.Substring(0, 10).Replace(':', '-');
                    string timePart = exifDateTime.Substring(11, 8);
                    return $"{datePart} {timePart}";
                }
                return exifDateTime;
            }
            catch
            {
                return exifDateTime;
            }
        }

        static string GetOrientation(PropertyItem[] properties, int width, int height)
        {
            try
            {
                string orientationValue = GetExifPropertyString(properties, 0x0112); // Orientation

                if (!string.IsNullOrEmpty(orientationValue))
                {
                    int orientation = int.Parse(orientationValue);

                    switch (orientation)
                    {
                        case 1: // Normal
                            return width >= height ? "Горизонтальная" : "Вертикальная";
                        case 2: // Mirror horizontal
                            return "Горизонтальная (зеркальная)";
                        case 3: // Rotate 180
                            return "Перевернутая";
                        case 4: // Mirror vertical
                            return "Вертикальная (зеркальная)";
                        case 5: // Mirror horizontal and rotate 270 CW
                        case 6: // Rotate 90 CW
                            return "Повернутая на 90°";
                        case 7: // Mirror horizontal and rotate 90 CW
                        case 8: // Rotate 270 CW
                            return "Повернутая на 270°";
                    }
                }

                // Если ориентация не указана, определяем по соотношению сторон
                return width >= height ? "Горизонтальная" : "Вертикальная";
            }
            catch
            {
                return width >= height ? "Горизонтальная" : "Вертикальная";
            }
        }

        static void DisplayAdditionalInfo(PropertyItem[] properties)
        {
            bool hasAdditionalInfo = false;

            // EXIF версия
            string exifVersion = GetExifPropertyString(properties, 0x9000); // ExifVersion
            if (!string.IsNullOrEmpty(exifVersion))
            {
                Console.WriteLine($"EXIF версия: {exifVersion}");
                hasAdditionalInfo = true;
            }

            // Диафрагма
            string fNumber = GetExifPropertyRational(properties, 0x829D); // FNumber
            if (!string.IsNullOrEmpty(fNumber))
            {
                Console.WriteLine($"Диафрагма: f/{fNumber}");
                hasAdditionalInfo = true;
            }

            // Выдержка
            string exposureTime = GetExifPropertyRational(properties, 0x829A); // ExposureTime
            if (!string.IsNullOrEmpty(exposureTime))
            {
                Console.WriteLine($"Выдержка: {exposureTime} сек.");
                hasAdditionalInfo = true;
            }

            // ISO
            string iso = GetExifPropertyString(properties, 0x8827); // ISOSpeedRatings
            if (!string.IsNullOrEmpty(iso))
            {
                Console.WriteLine($"ISO: {iso}");
                hasAdditionalInfo = true;
            }

            // Фокусное расстояние
            string focalLength = GetExifPropertyRational(properties, 0x920A); // FocalLength
            if (!string.IsNullOrEmpty(focalLength))
            {
                Console.WriteLine($"Фокусное расстояние: {focalLength} мм");
                hasAdditionalInfo = true;
            }

            if (hasAdditionalInfo)
            {
                Console.WriteLine(new string('-', 40));
            }
        }

        static string GetExifPropertyRational(PropertyItem[] properties, int propertyId)
        {
            foreach (var prop in properties)
            {
                if (prop.Id == propertyId && prop.Type == 5) // Rational type
                {
                    if (prop.Value.Length >= 8)
                    {
                        uint numerator = BitConverter.ToUInt32(prop.Value, 0);
                        uint denominator = BitConverter.ToUInt32(prop.Value, 4);

                        if (denominator != 0)
                        {
                            double value = (double)numerator / denominator;
                            return value.ToString("0.##");
                        }
                    }
                }
            }
            return null;
        }
    }
}
