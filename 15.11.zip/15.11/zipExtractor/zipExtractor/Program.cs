﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace ZipExtractor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("=== ZIP Extractor ===");

            while (true)
            {
                ShowMainMenu();
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ExtractFromZip();
                        break;
                    case "2":
                        CreateZip();
                        break;
                    case "3":
                        Console.WriteLine("Выход из программы.");
                        return;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }

                Console.WriteLine();
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("1. Извлечь файлы из ZIP-архива");
            Console.WriteLine("2. Создать ZIP-архив из папки");
            Console.WriteLine("3. Выход");
            Console.Write("Выберите действие: ");
        }

        static void ExtractFromZip()
        {
            try
            {
                // Ввод пути к архиву
                Console.Write("Введите путь к ZIP-архиву: ");
                string zipPath = Console.ReadLine()?.Trim(' ', '"');

                if (string.IsNullOrWhiteSpace(zipPath))
                {
                    Console.WriteLine("Ошибка: Путь не может быть пустым.");
                    return;
                }

                if (!File.Exists(zipPath))
                {
                    Console.WriteLine($"Ошибка: Файл '{zipPath}' не найден.");
                    return;
                }

                // Открытие архива и показ содержимого
                using (var archive = ZipFile.OpenRead(zipPath))
                {
                    if (archive.Entries.Count == 0)
                    {
                        Console.WriteLine("Архив пуст.");
                        return;
                    }

                    ShowArchiveContents(archive);
                    ShowExtractionMenu(archive, zipPath);
                }
            }
            catch (InvalidDataException)
            {
                Console.WriteLine("Ошибка: Файл не является корректным ZIP-архивом или поврежден.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }
        }

        static void ShowArchiveContents(ZipArchive archive)
        {
            Console.WriteLine($"\nСодержимое архива ({archive.Entries.Count} записей):");
            Console.WriteLine(new string('-', 80));

            long totalSize = 0;
            int fileIndex = 1;

            // Группируем записи по папкам для красивого отображения
            var files = archive.Entries.Where(e => !IsDirectory(e)).ToList();
            var directories = archive.Entries.Where(IsDirectory).ToList();

            // Показываем папки
            foreach (var dir in directories.OrderBy(d => d.FullName))
            {
                Console.WriteLine($"[DIR]  {dir.FullName}");
            }

            // Показываем файлы с номерами
            foreach (var file in files.OrderBy(f => f.FullName))
            {
                totalSize += file.Length;
                Console.WriteLine($"[{fileIndex,3}]  {file.FullName,-50} {file.Length,10} bytes");
                fileIndex++;
            }

            Console.WriteLine(new string('-', 80));
            Console.WriteLine($"Общий размер файлов: {totalSize} bytes ({FormatFileSize(totalSize)})");
        }

        static void ShowExtractionMenu(ZipArchive archive, string zipPath)
        {
            Console.WriteLine("\nОпции извлечения:");
            Console.WriteLine("1. Извлечь все файлы");
            Console.WriteLine("2. Извлечь выбранный файл по номеру");
            Console.WriteLine("3. Извлечь файлы по расширению");
            Console.WriteLine("4. Извлечь файлы по размеру");
            Console.Write("Выберите опцию: ");

            var choice = Console.ReadLine();
            var files = archive.Entries.Where(e => !IsDirectory(e)).OrderBy(f => f.FullName).ToList();

            switch (choice)
            {
                case "1":
                    ExtractAllFiles(archive, zipPath);
                    break;
                case "2":
                    ExtractSelectedFile(files, zipPath);
                    break;
                case "3":
                    ExtractByExtension(files, zipPath);
                    break;
                case "4":
                    ExtractBySize(files, zipPath);
                    break;
                default:
                    Console.WriteLine("Неверный выбор.");
                    break;
            }
        }

        static void ExtractAllFiles(ZipArchive archive, string zipPath)
        {
            Console.Write("Введите путь для извлечения: ");
            string extractPath = Console.ReadLine()?.Trim(' ', '"');

            if (string.IsNullOrWhiteSpace(extractPath))
            {
                Console.WriteLine("Ошибка: Путь не может быть пустым.");
                return;
            }

            // Создаем папку если не существует
            Directory.CreateDirectory(extractPath);

            Console.Write("Перезаписывать существующие файлы? (y/N): ");
            bool overwrite = Console.ReadLine()?.Trim().ToLower() == "y";

            int extractedCount = 0;
            int skippedCount = 0;

            foreach (var entry in archive.Entries)
            {
                if (IsDirectory(entry))
                    continue;

                string fullPath = Path.Combine(extractPath, entry.FullName);
                string directory = Path.GetDirectoryName(fullPath);

                // Создаем папки если нужно
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Проверяем существование файла
                if (File.Exists(fullPath) && !overwrite)
                {
                    Console.WriteLine($"Пропущен: {entry.FullName} (файл уже существует)");
                    skippedCount++;
                    continue;
                }

                try
                {
                    entry.ExtractToFile(fullPath, overwrite);
                    Console.WriteLine($"Извлечен: {entry.FullName}");
                    extractedCount++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при извлечении {entry.FullName}: {ex.Message}");
                }
            }

            Console.WriteLine($"\nИзвлечение завершено: {extractedCount} файлов извлечено, {skippedCount} пропущено.");
        }

        static void ExtractSelectedFile(List<ZipArchiveEntry> files, string zipPath)
        {
            if (!files.Any())
            {
                Console.WriteLine("В архиве нет файлов для извлечения.");
                return;
            }

            Console.Write($"Введите номер файла для извлечения (1-{files.Count}): ");
            if (!int.TryParse(Console.ReadLine(), out int fileNumber) || fileNumber < 1 || fileNumber > files.Count)
            {
                Console.WriteLine("Неверный номер файла.");
                return;
            }

            var selectedFile = files[fileNumber - 1];
            Console.Write("Введите путь для извлечения: ");
            string extractPath = Console.ReadLine()?.Trim(' ', '"');

            if (string.IsNullOrWhiteSpace(extractPath))
            {
                Console.WriteLine("Ошибка: Путь не может быть пустым.");
                return;
            }

            ExtractSingleFile(selectedFile, extractPath);
        }

        static void ExtractByExtension(List<ZipArchiveEntry> files, string zipPath)
        {
            if (!files.Any())
            {
                Console.WriteLine("В архиве нет файлов для извлечения.");
                return;
            }

            Console.Write("Введите расширение файлов (например: .txt, .jpg): ");
            string extension = Console.ReadLine()?.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(extension))
            {
                Console.WriteLine("Расширение не может быть пустым.");
                return;
            }

            if (!extension.StartsWith("."))
            {
                extension = "." + extension;
            }

            var filteredFiles = files.Where(f => f.Name.ToLower().EndsWith(extension)).ToList();

            if (!filteredFiles.Any())
            {
                Console.WriteLine($"Файлы с расширением '{extension}' не найдены.");
                return;
            }

            Console.WriteLine($"Найдено {filteredFiles.Count} файлов с расширением '{extension}':");
            foreach (var file in filteredFiles)
            {
                Console.WriteLine($"  {file.FullName}");
            }

            Console.Write("Извлечь эти файлы? (y/N): ");
            if (Console.ReadLine()?.Trim().ToLower() != "y")
                return;

            Console.Write("Введите путь для извлечения: ");
            string extractPath = Console.ReadLine()?.Trim(' ', '"');

            if (string.IsNullOrWhiteSpace(extractPath))
            {
                Console.WriteLine("Ошибка: Путь не может быть пустым.");
                return;
            }

            Console.Write("Перезаписывать существующие файлы? (y/N): ");
            bool overwrite = Console.ReadLine()?.Trim().ToLower() == "y";

            ExtractFiles(filteredFiles, extractPath, overwrite);
        }

        static void ExtractBySize(List<ZipArchiveEntry> files, string zipPath)
        {
            if (!files.Any())
            {
                Console.WriteLine("В архиве нет файлов для извлечения.");
                return;
            }

            Console.WriteLine("Фильтр по размеру:");
            Console.WriteLine("1. Меньше указанного размера");
            Console.WriteLine("2. Больше указанного размера");
            Console.WriteLine("3. В диапазоне размеров");
            Console.Write("Выберите тип фильтра: ");

            var filterChoice = Console.ReadLine();
            long minSize = 0, maxSize = long.MaxValue;

            switch (filterChoice)
            {
                case "1":
                    Console.Write("Введите максимальный размер в байтах: ");
                    if (long.TryParse(Console.ReadLine(), out maxSize))
                    {
                        minSize = 0;
                    }
                    break;
                case "2":
                    Console.Write("Введите минимальный размер в байтах: ");
                    if (long.TryParse(Console.ReadLine(), out minSize))
                    {
                        maxSize = long.MaxValue;
                    }
                    break;
                case "3":
                    Console.Write("Введите минимальный размер в байтах: ");
                    long.TryParse(Console.ReadLine(), out minSize);
                    Console.Write("Введите максимальный размер в байтах: ");
                    long.TryParse(Console.ReadLine(), out maxSize);
                    break;
                default:
                    Console.WriteLine("Неверный выбор.");
                    return;
            }

            var filteredFiles = files.Where(f => f.Length >= minSize && f.Length <= maxSize).ToList();

            if (!filteredFiles.Any())
            {
                Console.WriteLine($"Файлы в диапазоне {minSize}-{maxSize} байт не найдены.");
                return;
            }

            Console.WriteLine($"Найдено {filteredFiles.Count} файлов в указанном диапазоне:");
            foreach (var file in filteredFiles)
            {
                Console.WriteLine($"  {file.FullName} - {file.Length} bytes");
            }

            Console.Write("Извлечь эти файлы? (y/N): ");
            if (Console.ReadLine()?.Trim().ToLower() != "y")
                return;

            Console.Write("Введите путь для извлечения: ");
            string extractPath = Console.ReadLine()?.Trim(' ', '"');

            if (string.IsNullOrWhiteSpace(extractPath))
            {
                Console.WriteLine("Ошибка: Путь не может быть пустым.");
                return;
            }

            Console.Write("Перезаписывать существующие файлы? (y/N): ");
            bool overwrite = Console.ReadLine()?.Trim().ToLower() == "y";

            ExtractFiles(filteredFiles, extractPath, overwrite);
        }

        static void ExtractSingleFile(ZipArchiveEntry file, string extractPath)
        {
            string fullPath = Path.Combine(extractPath, file.Name);
            string directory = Path.GetDirectoryName(fullPath);

            // Создаем папку если нужно
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Проверяем существование файла
            if (File.Exists(fullPath))
            {
                Console.Write($"Файл '{file.Name}' уже существует. Перезаписать? (y/N): ");
                bool overwrite = Console.ReadLine()?.Trim().ToLower() == "y";

                if (!overwrite)
                {
                    Console.WriteLine("Извлечение отменено.");
                    return;
                }
            }

            try
            {
                file.ExtractToFile(fullPath, true);
                Console.WriteLine($"Файл '{file.Name}' успешно извлечен в '{fullPath}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при извлечении файла: {ex.Message}");
            }
        }

        static void ExtractFiles(List<ZipArchiveEntry> files, string extractPath, bool overwrite)
        {
            Directory.CreateDirectory(extractPath);

            int extractedCount = 0;
            int skippedCount = 0;

            foreach (var file in files)
            {
                string fullPath = Path.Combine(extractPath, file.FullName);
                string directory = Path.GetDirectoryName(fullPath);

                // Создаем папки если нужно
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Проверяем существование файла
                if (File.Exists(fullPath) && !overwrite)
                {
                    Console.WriteLine($"Пропущен: {file.FullName} (файл уже существует)");
                    skippedCount++;
                    continue;
                }

                try
                {
                    file.ExtractToFile(fullPath, overwrite);
                    Console.WriteLine($"Извлечен: {file.FullName}");
                    extractedCount++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при извлечении {file.FullName}: {ex.Message}");
                }
            }

            Console.WriteLine($"\nИзвлечение завершено: {extractedCount} файлов извлечено, {skippedCount} пропущено.");
        }

        static void CreateZip()
        {
            try
            {
                Console.Write("Введите путь к папке для архивации: ");
                string sourcePath = Console.ReadLine()?.Trim(' ', '"');

                if (string.IsNullOrWhiteSpace(sourcePath) || !Directory.Exists(sourcePath))
                {
                    Console.WriteLine("Ошибка: Папка не существует или путь пустой.");
                    return;
                }

                Console.Write("Введите путь для сохранения ZIP-архива: ");
                string zipPath = Console.ReadLine()?.Trim(' ', '"');

                if (string.IsNullOrWhiteSpace(zipPath))
                {
                    Console.WriteLine("Ошибка: Путь не может быть пустым.");
                    return;
                }

                // Добавляем расширение .zip если не указано
                if (!zipPath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    zipPath += ".zip";
                }

                Console.Write("Включить вложенные папки? (y/N): ");
                bool includeSubdirectories = Console.ReadLine()?.Trim().ToLower() == "y";

                // Проверяем существование файла архива
                if (File.Exists(zipPath))
                {
                    Console.Write($"Файл '{zipPath}' уже существует. Перезаписать? (y/N): ");
                    bool overwrite = Console.ReadLine()?.Trim().ToLower() == "y";

                    if (!overwrite)
                    {
                        Console.WriteLine("Создание архива отменено.");
                        return;
                    }
                    File.Delete(zipPath);
                }

                CreateZipArchive(sourcePath, zipPath, includeSubdirectories);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при создании архива: {ex.Message}");
            }
        }

        static void CreateZipArchive(string sourcePath, string zipPath, bool includeSubdirectories)
        {
            var files = Directory.GetFiles(sourcePath, "*",
                includeSubdirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);

            if (!files.Any())
            {
                Console.WriteLine("В указанной папке нет файлов для архивации.");
                return;
            }

            using (var zipArchive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
            {
                int addedCount = 0;
                string basePath = sourcePath.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

                foreach (string file in files)
                {
                    try
                    {
                        string entryName = file.Replace(basePath, "").Replace(Path.DirectorySeparatorChar, '/');
                        zipArchive.CreateEntryFromFile(file, entryName, CompressionLevel.Optimal);
                        Console.WriteLine($"Добавлен: {entryName}");
                        addedCount++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при добавлении файла {file}: {ex.Message}");
                    }
                }

                Console.WriteLine($"\nАрхив создан: {zipPath}");
                Console.WriteLine($"Добавлено файлов: {addedCount}");
                Console.WriteLine($"Размер архива: {FormatFileSize(new FileInfo(zipPath).Length)}");
            }
        }

        static bool IsDirectory(ZipArchiveEntry entry)
        {
            return entry.FullName.EndsWith("/") || string.IsNullOrEmpty(entry.Name);
        }

        static string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double size = bytes;

            while (size >= 1024 && order < sizes.Length - 1)
            {
                order++;
                size /= 1024;
            }

            return $"{size:0.##} {sizes[order]}";
        }
    }
}