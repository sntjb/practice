﻿using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace ZipArchiveAnalyzer
{
    class Program
    {
        private const int BytesToShow = 32;

        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("=== Анализатор ZIP-архивов ===");

                // Ввод пути к архиву
                Console.Write("Введите путь к .zip архиву: ");
                string zipPath = Console.ReadLine()?.Trim(' ', '"');

                if (string.IsNullOrWhiteSpace(zipPath))
                {
                    Console.WriteLine("Ошибка: Путь не может быть пустым.");
                    return;
                }

                // Проверка существования файла
                if (!File.Exists(zipPath))
                {
                    Console.WriteLine($"Ошибка: Файл '{zipPath}' не найден.");
                    return;
                }

                // Запрос о вычислении CRC32
                Console.Write("Вычислять CRC32 для каждой записи? (y/N): ");
                bool calculateCrc = Console.ReadLine()?.Trim().ToLower() == "y";

                AnalyzeZipArchive(zipPath, calculateCrc);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static void AnalyzeZipArchive(string zipPath, bool calculateCrc)
        {
            try
            {
                using (var fileStream = new FileStream(zipPath, FileMode.Open, FileAccess.Read))
                using (var archive = new ZipArchive(fileStream, ZipArchiveMode.Read))
                {
                    string fileName = Path.GetFileName(zipPath);
                    Console.WriteLine($"\nАрхив: {fileName}");
                    Console.WriteLine($"Записей: {archive.Entries.Count}");
                    Console.WriteLine(new string('-', 80));

                    int index = 1;
                    foreach (var entry in archive.Entries)
                    {
                        Console.WriteLine($"[{index}] {entry.FullName}");
                        Console.WriteLine($"Папка: {IsDirectory(entry)}");
                        Console.WriteLine($"Размер (без сжатия): {entry.Length} bytes");
                        Console.WriteLine($"Сжатый размер: {entry.CompressedLength} bytes");
                        Console.WriteLine($"Время модификации: {entry.LastWriteTime.DateTime:yyyy-MM-dd HH:mm:ss}");

                        // Вычисление CRC32 если запрошено и это файл
                        if (calculateCrc && !IsDirectory(entry))
                        {
                            uint crc32 = CalculateCrc32(entry);
                            Console.WriteLine($"CRC32: 0x{crc32:X8} ({crc32})");
                        }

                        // Показ первых байт для файлов
                        if (!IsDirectory(entry))
                        {
                            string hexBytes = GetFirstBytesHex(entry, BytesToShow);
                            Console.WriteLine($"Первые байты (hex): {hexBytes}");
                        }

                        Console.WriteLine(new string('-', 80));
                        index++;
                    }
                }
            }
            catch (InvalidDataException)
            {
                throw new InvalidDataException("Файл не является корректным ZIP-архивом или поврежден.");
            }
            catch (UnauthorizedAccessException)
            {
                throw new UnauthorizedAccessException("Нет доступа к файлу.");
            }
            catch (IOException ex)
            {
                throw new IOException($"Ошибка ввода-вывода: {ex.Message}");
            }
        }

        static bool IsDirectory(ZipArchiveEntry entry)
        {
            // Проверка, является ли запись директорией
            return entry.FullName.EndsWith("/") || string.IsNullOrEmpty(entry.Name);
        }

        static string GetFirstBytesHex(ZipArchiveEntry entry, int bytesCount)
        {
            if (entry.Length == 0) return "[пустой файл]";

            try
            {
                using (var entryStream = entry.Open())
                {
                    byte[] buffer = new byte[Math.Min(bytesCount, entry.Length)];
                    int bytesRead = entryStream.Read(buffer, 0, buffer.Length);

                    if (bytesRead == 0) return "[не удалось прочитать]";

                    var hexBuilder = new StringBuilder();
                    for (int i = 0; i < bytesRead; i++)
                    {
                        hexBuilder.Append($"{buffer[i]:X2}");
                        if (i < bytesRead - 1) hexBuilder.Append(" ");
                    }

                    if (bytesRead < bytesCount && bytesRead < entry.Length)
                        hexBuilder.Append(" ...");

                    return hexBuilder.ToString();
                }
            }
            catch (Exception ex)
            {
                return $"[ошибка чтения: {ex.Message}]";
            }
        }

        static uint CalculateCrc32(ZipArchiveEntry entry)
        {
            if (entry.Length == 0) return 0;

            const uint polynomial = 0xEDB88320;
            uint[] crcTable = new uint[256];

            // Инициализация таблицы CRC32
            for (uint i = 0; i < 256; i++)
            {
                uint crc = i;
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) != 0)
                        crc = (crc >> 1) ^ polynomial;
                    else
                        crc >>= 1;
                }
                crcTable[i] = crc;
            }

            try
            {
                using (var entryStream = entry.Open())
                {
                    uint crc = 0xFFFFFFFF;
                    byte[] buffer = new byte[4096];
                    int bytesRead;

                    while ((bytesRead = entryStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        for (int i = 0; i < bytesRead; i++)
                        {
                            byte tableIndex = (byte)((crc & 0xFF) ^ buffer[i]);
                            crc = (crc >> 8) ^ crcTable[tableIndex];
                        }
                    }

                    return crc ^ 0xFFFFFFFF;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при вычислении CRC32 для {entry.FullName}: {ex.Message}");
                return 0;
            }
        }
    }
}