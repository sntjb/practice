﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace EmployeesCatalog
{
    public struct Employee
    {
        public string Name;
        public string Position;
        public decimal Salary;

        public override string ToString()
        {
            return $"{Name} - {Position} - {Salary:C}";
        }
    }

    class Program
    {
        private const string FilePath = @"C:\\Users\\nayde\\Desktop\\11.11\\employeesCatalog\\employeesCatalog\\Resources\\employees.txt";

        static void Main(string[] args)
        {
            Console.WriteLine("=== СИСТЕМА УПРАВЛЕНИЯ СОТРУДНИКАМИ ===");

            while (true)
            {
                ShowMainMenu();
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddEmployee();
                        break;
                    case "2":
                        ShowAllEmployees();
                        break;
                    case "3":
                        ShowEmployeesAboveSalary();
                        break;
                    case "4":
                        ShowAverageSalary();
                        break;
                    case "5":
                        Console.WriteLine("Выход из программы.");
                        return;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }

                Console.WriteLine();
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("1. Добавить сотрудника");
            Console.WriteLine("2. Показать всех сотрудников");
            Console.WriteLine("3. Показать сотрудников с зарплатой выше заданной");
            Console.WriteLine("4. Показать среднюю зарплату");
            Console.WriteLine("5. Выход");
            Console.Write("Выберите действие: ");
        }

        static List<Employee> ReadEmployeesFromFile()
        {
            var employees = new List<Employee>();

            if (!File.Exists(FilePath))
            {
                Console.WriteLine("Файл employees.txt не найден.");
                return employees;
            }

            try
            {
                var lines = File.ReadAllLines(FilePath);
                Employee currentEmployee = new Employee();

                foreach (var line in lines)
                {
                    if (line.StartsWith("Name:"))
                    {
                        if (!string.IsNullOrEmpty(currentEmployee.Name))
                        {
                            employees.Add(currentEmployee);
                            currentEmployee = new Employee();
                        }
                        currentEmployee.Name = line.Substring(5).Trim();
                    }
                    else if (line.StartsWith("Position:"))
                    {
                        currentEmployee.Position = line.Substring(9).Trim();
                    }
                    else if (line.StartsWith("Salary:"))
                    {
                        string salaryStr = line.Substring(7).Trim();
                        if (decimal.TryParse(salaryStr, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal salary))
                        {
                            currentEmployee.Salary = salary;
                        }
                    }
                    else if (string.IsNullOrWhiteSpace(line))
                    {
                        if (!string.IsNullOrEmpty(currentEmployee.Name))
                        {
                            employees.Add(currentEmployee);
                            currentEmployee = new Employee();
                        }
                    }
                }

                if (!string.IsNullOrEmpty(currentEmployee.Name))
                {
                    employees.Add(currentEmployee);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
            }

            return employees;
        }

        static void SaveEmployeeToFile(Employee employee)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(FilePath, true))
                {
                    writer.WriteLine($"Name: {employee.Name}");
                    writer.WriteLine($"Position: {employee.Position}");
                    writer.WriteLine($"Salary: {employee.Salary}");
                    writer.WriteLine();
                }
                Console.WriteLine("Сотрудник успешно добавлен.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении: {ex.Message}");
            }
        }

        static void AddEmployee()
        {
            Console.Write("Введите ФИО сотрудника: ");
            string name = Console.ReadLine();

            Console.Write("Введите должность: ");
            string position = Console.ReadLine();

            Console.Write("Введите зарплату: ");
            string salaryInput = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(position) ||
                !decimal.TryParse(salaryInput, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal salary))
            {
                Console.WriteLine("Ошибка ввода данных. Проверьте корректность введенных значений.");
                return;
            }

            var employee = new Employee
            {
                Name = name,
                Position = position,
                Salary = salary
            };

            SaveEmployeeToFile(employee);
        }

        static void ShowAllEmployees()
        {
            var employees = ReadEmployeesFromFile();

            if (employees.Count == 0)
            {
                Console.WriteLine("Сотрудники не найдены.");
                return;
            }

            Console.WriteLine($"\nСписок всех сотрудников ({employees.Count}):");
            Console.WriteLine(new string('-', 60));

            foreach (var employee in employees)
            {
                Console.WriteLine(employee);
            }
        }

        static void ShowEmployeesAboveSalary()
        {
            Console.Write("Введите минимальную зарплату: ");
            if (!decimal.TryParse(Console.ReadLine(), NumberStyles.Number, CultureInfo.InvariantCulture, out decimal minSalary))
            {
                Console.WriteLine("Неверный формат зарплаты.");
                return;
            }

            var employees = ReadEmployeesFromFile();
            var filteredEmployees = employees.Where(e => e.Salary > minSalary).ToList();

            if (filteredEmployees.Count == 0)
            {
                Console.WriteLine($"Сотрудники с зарплатой выше {minSalary:C} не найдены.");
                return;
            }

            Console.WriteLine($"\nСотрудники с зарплатой выше {minSalary:C} ({filteredEmployees.Count}):");
            Console.WriteLine(new string('-', 60));

            foreach (var employee in filteredEmployees)
            {
                Console.WriteLine(employee);
            }
        }

        static void ShowAverageSalary()
        {
            var employees = ReadEmployeesFromFile();

            if (employees.Count == 0)
            {
                Console.WriteLine("Нет данных для расчета средней зарплаты.");
                return;
            }

            decimal averageSalary = employees.Average(e => e.Salary);
            decimal totalSalary = employees.Sum(e => e.Salary);
            decimal maxSalary = employees.Max(e => e.Salary);
            decimal minSalary = employees.Min(e => e.Salary);

            Console.WriteLine($"\nСтатистика по зарплатам:");
            Console.WriteLine(new string('-', 40));
            Console.WriteLine($"Количество сотрудников: {employees.Count}");
            Console.WriteLine($"Общий фонд зарплат: {totalSalary:C}");
            Console.WriteLine($"Средняя зарплата: {averageSalary:C}");
            Console.WriteLine($"Максимальная зарплата: {maxSalary:C}");
            Console.WriteLine($"Минимальная зарплата: {minSalary:C}");
        }
    }
}