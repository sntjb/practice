﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace FinanceCatalog
{
    public struct Transaction
    {
        public DateTime Date;
        public string Category;
        public decimal Amount;

        public override string ToString()
        {
            string type = Amount >= 0 ? "Доход" : "Расход";
            return $"{Date:dd.MM.yyyy} - {Category} - {Math.Abs(Amount):C} ({type})";
        }
    }

    class Program
    {
        private const string FilePath = @"C:\\Users\\nayde\\Desktop\\11.11\\financeCatalog\\financeCatalog\\Resources\\finance.txt";

        static void Main(string[] args)
        {
            Console.WriteLine("=== ФИНАНСОВЫЙ МЕНЕДЖЕР ===");

            while (true)
            {
                ShowMainMenu();
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ShowFinancialSummary();
                        break;
                    case "2":
                        ShowAllTransactions();
                        break;
                    case "3":
                        ShowTransactionsByCategory();
                        break;
                    case "4":
                        AddTransaction();
                        break;
                    case "5":
                        Console.WriteLine("Выход из программы.");
                        return;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }

                Console.WriteLine();
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("1. Общий финансовый отчет");
            Console.WriteLine("2. Показать все операции");
            Console.WriteLine("3. Показать операции по категории");
            Console.WriteLine("4. Добавить операцию");
            Console.WriteLine("5. Выход");
            Console.Write("Выберите действие: ");
        }

        static List<Transaction> ReadTransactionsFromFile()
        {
            var transactions = new List<Transaction>();

            if (!File.Exists(FilePath))
            {
                Console.WriteLine("Файл finance.txt не найден.");
                return transactions;
            }

            try
            {
                var lines = File.ReadAllLines(FilePath);
                Transaction currentTransaction = new Transaction();

                foreach (var line in lines)
                {
                    if (line.StartsWith("Date:"))
                    {
                        if (currentTransaction.Date != DateTime.MinValue)
                        {
                            transactions.Add(currentTransaction);
                            currentTransaction = new Transaction();
                        }

                        string dateStr = line.Substring(5).Trim();
                        if (DateTime.TryParseExact(dateStr, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
                        {
                            currentTransaction.Date = date;
                        }
                    }
                    else if (line.StartsWith("Category:"))
                    {
                        currentTransaction.Category = line.Substring(9).Trim();
                    }
                    else if (line.StartsWith("Amount:"))
                    {
                        string amountStr = line.Substring(7).Trim();
                        if (decimal.TryParse(amountStr, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal amount))
                        {
                            currentTransaction.Amount = amount;
                        }
                    }
                    else if (string.IsNullOrWhiteSpace(line))
                    {
                        if (currentTransaction.Date != DateTime.MinValue)
                        {
                            transactions.Add(currentTransaction);
                            currentTransaction = new Transaction();
                        }
                    }
                }

                if (currentTransaction.Date != DateTime.MinValue)
                {
                    transactions.Add(currentTransaction);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
            }

            return transactions;
        }

        static void SaveTransactionToFile(Transaction transaction)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(FilePath, true))
                {
                    writer.WriteLine($"Date: {transaction.Date:yyyy-MM-dd}");
                    writer.WriteLine($"Category: {transaction.Category}");
                    writer.WriteLine($"Amount: {transaction.Amount}");
                    writer.WriteLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении: {ex.Message}");
            }
        }

        static void ShowFinancialSummary()
        {
            var transactions = ReadTransactionsFromFile();

            if (transactions.Count == 0)
            {
                Console.WriteLine("Нет данных для анализа.");
                return;
            }

            decimal totalIncome = transactions.Where(t => t.Amount > 0).Sum(t => t.Amount);
            decimal totalExpenses = Math.Abs(transactions.Where(t => t.Amount < 0).Sum(t => t.Amount));
            decimal balance = totalIncome - totalExpenses;

            Console.WriteLine("\nФИНАНСОВЫЙ ОТЧЕТ");
            Console.WriteLine(new string('=', 40));
            Console.WriteLine($"Общее количество операций: {transactions.Count}");
            Console.WriteLine($"Доходы: {totalIncome:C}");
            Console.WriteLine($"Расходы: {totalExpenses:C}");
            Console.WriteLine($"Баланс: {balance:C}");
            Console.WriteLine(new string('=', 40));

            if (balance > 0)
                Console.WriteLine("Положительный баланс");
            else if (balance < 0)
                Console.WriteLine("Отрицательный баланс");
            else
                Console.WriteLine("Нулевой баланс");

            // Статистика по категориям
            var categoryStats = transactions
                .GroupBy(t => t.Category)
                .Select(g => new { Category = g.Key, Total = g.Sum(t => t.Amount) })
                .OrderByDescending(x => Math.Abs(x.Total));

            Console.WriteLine("\nСтатистика по категориям:");
            foreach (var stat in categoryStats)
            {
                string type = stat.Total >= 0 ? "Доход" : "Расход";
                Console.WriteLine($"  {stat.Category}: {Math.Abs(stat.Total):C} ({type})");
            }
        }

        static void ShowAllTransactions()
        {
            var transactions = ReadTransactionsFromFile();

            if (transactions.Count == 0)
            {
                Console.WriteLine("Операции не найдены.");
                return;
            }

            var sortedTransactions = transactions.OrderBy(t => t.Date).ToList();

            Console.WriteLine($"\nВсе операции ({sortedTransactions.Count}):");
            Console.WriteLine(new string('-', 60));

            foreach (var transaction in sortedTransactions)
            {
                Console.WriteLine(transaction);
            }
        }

        static void ShowTransactionsByCategory()
        {
            var transactions = ReadTransactionsFromFile();

            if (transactions.Count == 0)
            {
                Console.WriteLine("Операции не найдены.");
                return;
            }

            var categories = transactions.Select(t => t.Category).Distinct().OrderBy(c => c).ToList();

            Console.WriteLine("Доступные категории:");
            for (int i = 0; i < categories.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {categories[i]}");
            }

            Console.Write("Выберите категорию (номер или название): ");
            string input = Console.ReadLine();

            string selectedCategory;
            if (int.TryParse(input, out int index) && index > 0 && index <= categories.Count)
            {
                selectedCategory = categories[index - 1];
            }
            else
            {
                selectedCategory = input;
            }

            var categoryTransactions = transactions
                .Where(t => t.Category.Equals(selectedCategory, StringComparison.OrdinalIgnoreCase))
                .OrderBy(t => t.Date)
                .ToList();

            if (categoryTransactions.Count == 0)
            {
                Console.WriteLine($"Операции в категории '{selectedCategory}' не найдены.");
                return;
            }

            decimal categoryTotal = categoryTransactions.Sum(t => t.Amount);

            Console.WriteLine($"\nОперации в категории '{selectedCategory}' ({categoryTransactions.Count}):");
            Console.WriteLine(new string('-', 60));

            foreach (var transaction in categoryTransactions)
            {
                Console.WriteLine(transaction);
            }

            Console.WriteLine(new string('-', 60));
            string totalType = categoryTotal >= 0 ? "Доход" : "Расход";
            Console.WriteLine($"Итого по категории: {Math.Abs(categoryTotal):C} ({totalType})");
        }

        static void AddTransaction()
        {
            Console.Write("Введите дату (гггг-мм-дд): ");
            if (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date))
            {
                Console.WriteLine("Неверный формат даты. Используйте формат: гггг-мм-дд");
                return;
            }

            Console.Write("Введите категорию: ");
            string category = Console.ReadLine();

            Console.Write("Введите сумму (положительная - доход, отрицательная - расход): ");
            if (!decimal.TryParse(Console.ReadLine(), NumberStyles.Number, CultureInfo.InvariantCulture, out decimal amount))
            {
                Console.WriteLine("Неверный формат суммы.");
                return;
            }

            if (string.IsNullOrWhiteSpace(category))
            {
                Console.WriteLine("Категория не может быть пустой.");
                return;
            }

            var transaction = new Transaction
            {
                Date = date,
                Category = category,
                Amount = amount
            };

            SaveTransactionToFile(transaction);
            Console.WriteLine("Операция успешно добавлена.");
        }
    }
}