﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DeviceInventory
{
    public struct Device
    {
        public string Name;
        public string Type;
        public string Status;

        public override string ToString()
        {
            return $"{Name} ({Type}) - {Status}";
        }
    }

    class Program
    {
        private const string FilePath = "C:\\Users\\nayde\\Desktop\\11.11\\deviceCatalog\\deviceCatalog\\Resources\\devices.txt";

        static void Main(string[] args)
        {
            Console.WriteLine("=== СИСТЕМА ИНВЕНТАРИЗАЦИИ ТЕХНИКИ ===");

            while (true)
            {
                ShowMainMenu();
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ShowAllDevices();
                        break;
                    case "2":
                        ShowNonWorkingDevices();
                        break;
                    case "3":
                        UpdateDeviceStatus();
                        break;
                    case "4":
                        AddNewDevice();
                        break;
                    case "5":
                        Console.WriteLine("Выход из программы.");
                        return;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }

                Console.WriteLine();
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("1. Показать все устройства");
            Console.WriteLine("2. Показать неработающие устройства");
            Console.WriteLine("3. Обновить статус устройства");
            Console.WriteLine("4. Добавить новое устройство");
            Console.WriteLine("5. Выход");
            Console.Write("Выберите действие: ");
        }

        static List<Device> ReadDevicesFromFile()
        {
            var devices = new List<Device>();

            if (!File.Exists(FilePath))
            {
                Console.WriteLine("Файл devices.txt не найден. Будет создан новый при добавлении устройств.");
                return devices;
            }

            try
            {
                var lines = File.ReadAllLines(FilePath);
                Device currentDevice = new Device();

                foreach (var line in lines)
                {
                    if (line.StartsWith("Name:"))
                    {
                        if (!string.IsNullOrEmpty(currentDevice.Name))
                        {
                            devices.Add(currentDevice);
                            currentDevice = new Device();
                        }
                        currentDevice.Name = line.Substring(5).Trim();
                    }
                    else if (line.StartsWith("Type:"))
                    {
                        currentDevice.Type = line.Substring(5).Trim();
                    }
                    else if (line.StartsWith("Status:"))
                    {
                        currentDevice.Status = line.Substring(7).Trim();
                    }
                    else if (string.IsNullOrWhiteSpace(line))
                    {
                        if (!string.IsNullOrEmpty(currentDevice.Name))
                        {
                            devices.Add(currentDevice);
                            currentDevice = new Device();
                        }
                    }
                }

                if (!string.IsNullOrEmpty(currentDevice.Name))
                {
                    devices.Add(currentDevice);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
            }

            return devices;
        }

        static void SaveDevicesToFile(List<Device> devices)
        {
            try
            {
                var lines = new List<string>();

                foreach (var device in devices)
                {
                    lines.Add($"Name: {device.Name}");
                    lines.Add($"Type: {device.Type}");
                    lines.Add($"Status: {device.Status}");
                    lines.Add("");
                }

                if (lines.Count > 0 && string.IsNullOrEmpty(lines[lines.Count - 1]))
                {
                    lines.RemoveAt(lines.Count - 1);
                }

                File.WriteAllLines(FilePath, lines);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении файла: {ex.Message}");
            }
        }

        static void ShowAllDevices()
        {
            var devices = ReadDevicesFromFile();

            if (devices.Count == 0)
            {
                Console.WriteLine("Устройства не найдены.");
                return;
            }

            Console.WriteLine($"\nСписок всех устройств ({devices.Count}):");
            Console.WriteLine(new string('-', 50));

            for (int i = 0; i < devices.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {devices[i]}");
            }
        }

        static void ShowNonWorkingDevices()
        {
            var devices = ReadDevicesFromFile();
            var nonWorking = devices.Where(d =>
                d.Status.ToLower().Contains("не") ||
                d.Status.ToLower().Contains("broken") ||
                d.Status.ToLower().Contains("error") ||
                d.Status.ToLower().Contains("сломан")).ToList();

            if (nonWorking.Count == 0)
            {
                Console.WriteLine("Неработающие устройства не найдены.");
                return;
            }

            Console.WriteLine($"\nНеработающие устройства ({nonWorking.Count}):");
            Console.WriteLine(new string('-', 50));

            foreach (var device in nonWorking)
            {
                Console.WriteLine(device);
            }
        }

        static void UpdateDeviceStatus()
        {
            var devices = ReadDevicesFromFile();

            if (devices.Count == 0)
            {
                Console.WriteLine("Нет устройств для обновления.");
                return;
            }

            ShowAllDevices();
            Console.Write("\nВведите номер устройства для обновления: ");

            if (int.TryParse(Console.ReadLine(), out int index) && index > 0 && index <= devices.Count)
            {
                Console.Write("Введите новый статус: ");
                string newStatus = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(newStatus))
                {
                    var updatedDevices = new List<Device>();
                    for (int i = 0; i < devices.Count; i++)
                    {
                        if (i == index - 1)
                        {
                            updatedDevices.Add(new Device
                            {
                                Name = devices[i].Name,
                                Type = devices[i].Type,
                                Status = newStatus
                            });
                        }
                        else
                        {
                            updatedDevices.Add(devices[i]);
                        }
                    }

                    SaveDevicesToFile(updatedDevices);
                    Console.WriteLine("Статус устройства обновлен.");
                }
                else
                {
                    Console.WriteLine("Статус не может быть пустым.");
                }
            }
            else
            {
                Console.WriteLine("Неверный номер устройства.");
            }
        }

        static void AddNewDevice()
        {
            Console.Write("Введите название устройства: ");
            string name = Console.ReadLine();

            Console.Write("Введите тип устройства: ");
            string type = Console.ReadLine();

            Console.Write("Введите статус устройства: ");
            string status = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(status))
            {
                Console.WriteLine("Все поля должны быть заполнены.");
                return;
            }

            var devices = ReadDevicesFromFile();
            devices.Add(new Device { Name = name, Type = type, Status = status });
            SaveDevicesToFile(devices);

            Console.WriteLine("Устройство успешно добавлено.");
        }
    }
}