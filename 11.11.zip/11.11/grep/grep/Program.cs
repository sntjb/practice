﻿using System;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите путь до файла: ");
        string fileName = Console.ReadLine();

        Console.Write("Введите строку для поиска: ");
        string searchString = Console.ReadLine();

        try
        {
            List<string> matchingLines = new List<string>();

            using (StreamReader reader = new StreamReader(fileName))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Contains(searchString))
                    {
                        matchingLines.Add(line);
                    }
                }
            }

            if (matchingLines.Count > 0)
            {
                using (StreamWriter writer = new StreamWriter(@"C:\Users\nayde\Desktop\11.11\grep_result.txt"))
                {
                    foreach (string matchingLine in matchingLines)
                    {
                        writer.WriteLine(matchingLine);
                    }
                }
                Console.WriteLine($"Найдено {matchingLines.Count} совпадений. Результаты сохранены в grep_result.txt");
            }
            else
            {
                Console.WriteLine("Совпадений не найдено.");
            }
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Файл не найден.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Произошла ошибка: {ex.Message}");
        }
    }
}