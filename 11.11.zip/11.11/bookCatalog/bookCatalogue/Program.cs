﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;

namespace BookCatalog
{
    public struct Book
    {
        public string Title;
        public string Author;
        public int Year;
        public decimal Price;
    }

    class Program
    {
        private static readonly string filePath = @"C:\Users\nayde\Desktop\11.11\bookCatalog\bookCatalogue\Resources\books.txt";

        static void Main(string[] args)
        {
            Console.WriteLine("Каталог книг");

            while (true)
            {
                ShowMainMenu();
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        WriteBooksModule();
                        break;
                    case "2":
                        ReadBooksModule();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Неверный выбор");
                        break;
                }

                Console.WriteLine("Нажмите любую клавишу для продолжения");
                Console.ReadKey();
                Console.Clear();
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("Главное меню:");
            Console.WriteLine("1 - Записать книги в файл");
            Console.WriteLine("2 - Прочитать книги из файла");
            Console.WriteLine("3 - Выйти");
            Console.Write("Выберите действие: ");
        }

        static void WriteBooksModule()
        {
            Console.WriteLine("Запись книг в файл");
            Console.WriteLine("Сколько книг вы хотите ввести?");
            int number;
            try
            {
                number = int.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Ошибка: Введите целое положительное число.");
                return;
            }

            List<Book> books = new List<Book>();
            for (int i = 0; i < number; i++)
            {
                Console.WriteLine($"Книга {i + 1}:");
                Book book = new Book();

                Console.Write("Title: ");
                book.Title = Console.ReadLine();

                Console.Write("Author: ");
                book.Author = Console.ReadLine();

                book.Year = GetValidYear();
                book.Price = GetValidPrice();

                books.Add(book);
                Console.WriteLine();
            }

            SaveBooksToFile(books);
            Console.WriteLine("Книги сохранены в файл");
        }

        static void ReadBooksModule()
        {
            Console.WriteLine("Чтение книг из файла");

            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл не найден");
                return;
            }

            List<Book> books = ReadBooksFromFile();
            if (books.Count == 0)
            {
                Console.WriteLine("В файле нет книг");
                return;
            }

            Console.Write("Введите год для фильтрации: ");
            if (int.TryParse(Console.ReadLine(), out int filterYear))
            {
                var filteredBooks = books.Where(book => book.Year > filterYear).ToList();

                Console.WriteLine($"Книги изданные после {filterYear} года:");
                foreach (var book in filteredBooks)
                {
                    Console.WriteLine($"Title: {book.Title}");
                    Console.WriteLine($"Author: {book.Author}");
                    Console.WriteLine($"Year: {book.Year}");
                    Console.WriteLine($"Price: {book.Price}");
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Неверный год");
            }
        }

        static int GetValidYear()
        {
            while (true)
            {
                Console.Write("Year: ");
                if (int.TryParse(Console.ReadLine(), out int year) && year > 0 && year <= DateTime.Now.Year)
                {
                    return year;
                }
                Console.WriteLine("Неверный год");
            }
        }

        static decimal GetValidPrice()
        {
            while (true)
            {
                Console.Write("Price: ");
                string input = Console.ReadLine().Replace('.', ',');
                if (decimal.TryParse(input, out decimal price) && price >= 0)
                {
                    return price;
                }
                Console.WriteLine("Неверная цена");
            }
        }

        static void SaveBooksToFile(List<Book> books)
        {
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                foreach (Book book in books)
                {
                    writer.WriteLine($"Title: {book.Title}");
                    writer.WriteLine($"Author: {book.Author}");
                    writer.WriteLine($"Year: {book.Year}");
                    writer.WriteLine($"Price: {book.Price}");
                    writer.WriteLine();
                }
            }
        }

        static List<Book> ReadBooksFromFile()
        {
            List<Book> books = new List<Book>();

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                Book currentBook = new Book();
                int propertyCount = 0;

                while ((line = reader.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        if (propertyCount == 4)
                        {
                            books.Add(currentBook);
                            currentBook = new Book();
                            propertyCount = 0;
                        }
                        continue;
                    }

                    if (line.StartsWith("Title: "))
                    {
                        currentBook.Title = line.Substring(7);
                        propertyCount++;
                    }
                    else if (line.StartsWith("Author: "))
                    {
                        currentBook.Author = line.Substring(8);
                        propertyCount++;
                    }
                    else if (line.StartsWith("Year: "))
                    {
                        if (int.TryParse(line.Substring(6), out int year))
                        {
                            currentBook.Year = year;
                            propertyCount++;
                        }
                    }
                    else if (line.StartsWith("Price: "))
                    {
                        string priceStr = line.Substring(7).Replace('.', ',');
                        if (decimal.TryParse(priceStr, out decimal price))
                        {
                            currentBook.Price = price;
                            propertyCount++;
                        }
                    }
                }

                if (propertyCount == 4)
                {
                    books.Add(currentBook);
                }
            }

            return books;
        }
    }
}