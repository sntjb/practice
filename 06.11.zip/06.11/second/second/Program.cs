﻿using System;

namespace SplitMeal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Добро пожаловать в SplitMeal, приложение, которое избавит тебя от подсчётов и добавит авторитета в кругу друзей");

            double totalAmount = GetValidTotalAmount();
            int participants = GetValidParticipants();
            int tipPercentage = GetValidTipPercentage();

            double amountPerPerson = CalculateAmountPerPerson(totalAmount, participants, tipPercentage);

            Console.WriteLine($"Каждый должен заплатить: {amountPerPerson} рублей");
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static double GetValidTotalAmount()
        {
            while (true)
            {
                try
                {
                    Console.Write("Введите общую сумму обеда: ");
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        Console.WriteLine("Ошибка: Сумма не может быть пустой. Пожалуйста, введите число.");
                        continue;
                    }

                    if (double.Parse(input) < 1)
                    {
                        Console.WriteLine("Ошибка: Сумма не может быть меньше 1.");
                        continue;
                    }

                    if (input.Contains("."))
                    {
                        Console.WriteLine("Ошибка: Используйте запятую для дробных чисел. Пожалуйста, введите число с запятой.");
                        continue;
                    }

                    double amount = double.Parse(input);

                    if (amount <= 0)
                    {
                        Console.WriteLine("Ошибка: Сумма должна быть больше нуля. Пожалуйста, введите положительное число.");
                        continue;
                    }

                    if (HasMoreThanTwoDecimalPlaces(amount))
                    {
                        Console.WriteLine("Ошибка: Сумма не может иметь более 2 знаков после запятой.");
                        continue;
                    }

                    return amount;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка: Введите корректное число. Например: 1500 или 1250,50");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка: Сумма слишком большая. Пожалуйста, введите сумму до 1 000 000 рублей.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Неожиданная ошибка: {ex.Message}. Пожалуйста, попробуйте снова.");
                }
            }
        }

        static int GetValidParticipants()
        {
            while (true)
            {
                try
                {
                    Console.Write("Введите количество участников обеда: ");
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        Console.WriteLine("Ошибка: Количество участников не может быть пустым. Пожалуйста, введите число.");
                        continue;
                    }

                    foreach (char c in input)
                    {
                        if (!char.IsDigit(c))
                        {
                            Console.WriteLine("Ошибка: Количество участников должно быть целым числом. Пожалуйста, введите число без букв и символов.");
                            continue;
                        }
                    }

                    int participants = int.Parse(input);

                    if (participants <= 0)
                    {
                        Console.WriteLine("Ошибка: Количество участников должно быть больше нуля. Пожалуйста, введите положительное число.");
                        continue;
                    }

                    if (participants > 50)
                    {
                        Console.WriteLine("Ошибка: Слишком много участников. Максимум 50 человек.");
                        continue;
                    }

                    if (participants == 1)
                    {
                        Console.WriteLine("Ошибка: Если участник один, то и делить нечего! Введите количество больше 1.");
                        continue;
                    }

                    return participants;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка: Введите корректное целое число. Например: 3, 5, 10");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка: Число слишком большое. Пожалуйста, введите число до 50.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Неожиданная ошибка: {ex.Message}. Пожалуйста, попробуйте снова.");
                }
            }
        }

        static int GetValidTipPercentage()
        {
            while (true)
            {
                try
                {
                    Console.Write("Какой процент чаевых Вы оставляете 10, 12, 15: ");
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        Console.WriteLine("Ошибка: Процент чаевых не может быть пустым. Пожалуйста, введите число.");
                        continue;
                    }

                    foreach (char c in input)
                    {
                        if (!char.IsDigit(c))
                        {
                            Console.WriteLine("Ошибка: Процент чаевых должен быть числом. Пожалуйста, введите число без букв и символов.");
                            continue;
                        }
                    }

                    int percentage = int.Parse(input);

                    if (percentage != 10 && percentage != 12 && percentage != 15)
                    {
                        Console.WriteLine("Ошибка: Допустимые значения процента чаевых: 10, 12 или 15. Пожалуйста, выберите одно из этих значений.");
                        continue;
                    }

                    return percentage;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка: Введите корректное целое число. Допустимые значения: 10, 12 или 15.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка: Число слишком большое. Допустимые значения: 10, 12 или 15.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Неожиданная ошибка: {ex.Message}. Пожалуйста, попробуйте снова.");
                }
            }
        }

        static double CalculateAmountPerPerson(double totalAmount, int participants, int tipPercentage)
        {
            double totalWithTip = totalAmount * (1 + tipPercentage / 100.0);
            double amountPerPerson = totalWithTip / participants;

            return Math.Round(amountPerPerson, 2);
        }

        static bool HasMoreThanTwoDecimalPlaces(double number)
        {
            string numberString = number.ToString("0.00##");
            return numberString.Contains(",") && numberString.Split(',')[1].Length > 2;
        }

    }
}