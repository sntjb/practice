﻿using System;
using System.Linq;
using System.Text;

namespace PasswordGenerator
{
    class Program
    {
        private static readonly Random random = new Random();
        private const string LowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
        private const string UppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private const string Numbers = "0123456789";
        private const string SpecialCharacters = "!@#$%^&*()_+-=[]{}|;:,.<>?";

        static void Main(string[] args)
        {
            Console.WriteLine("Добро пожаловать в хакерский генератор паролей!");
            Console.WriteLine();

            try
            {
                int letterCount = GetValidCount("Сколько букв должно быть в пароле: ", "букв");
                int specialCharCount = GetValidCount("Сколько спецсимволов должно быть в пароле: ", "спецсимволов");
                int numberCount = GetValidCount("Сколько чисел должно быть в пароле: ", "чисел");

                int totalLength = letterCount + specialCharCount + numberCount;
                if (totalLength < 4)
                {
                    Console.WriteLine("Ошибка: Пароль должен содержать минимум 4 символа для безопасности.");
                    return;
                }

                if (totalLength > 16)
                {
                    Console.WriteLine("Ошибка: Пароль не может быть длиннее 16 символов.");
                    return;
                }

                string password = GeneratePassword(letterCount, specialCharCount, numberCount);

                Console.WriteLine();
                Console.WriteLine($"Ваш пароль: {password}");
                Console.WriteLine($"Длина пароля: {password.Length} символов");

                DisplayPasswordStrength(password);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла непредвиденная ошибка: {ex.Message}");
            }
            finally
            {
                Console.WriteLine();
                Console.WriteLine("Нажмите любую клавишу для выхода...");
                Console.ReadKey();
            }
        }

        static int GetValidCount(string prompt, string symbolType)
        {
            while (true)
            {
                try
                {
                    Console.Write(prompt);
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        Console.WriteLine($"Ошибка: Количество {symbolType} не может быть пустым.");
                        continue;
                    }

                    if (input.StartsWith("-"))
                    {
                        Console.WriteLine($"Ошибка: Количество {symbolType} не может быть отрицательным.");
                        continue;
                    }

                    if (!input.All(char.IsDigit))
                    {
                        Console.WriteLine($"Ошибка: Количество {symbolType} должно быть целым числом.");
                        continue;
                    }

                    int count = int.Parse(input);

                    if (count == 0 && symbolType == "букв")
                    {
                        Console.WriteLine("Внимание: Пароль без букв будет менее надежным. Вы уверены? (y/n)");
                        string response = Console.ReadLine()?.ToLower();
                        if (response != "y" && response != "yes" && response != "д" && response != "да")
                        {
                            continue;
                        }
                    }

                    if (count < 0)
                    {
                        Console.WriteLine($"Ошибка: Количество {symbolType} не может быть отрицательным.");
                        continue;
                    }

                    if (count > 16)
                    {
                        Console.WriteLine($"Ошибка: Слишком большое количество {symbolType}. Размер пароля не должен превышать 16 символов.");
                        continue;
                    }

                    return count;
                }
                catch (FormatException)
                {
                    Console.WriteLine($"Ошибка: Введите корректное целое число для количества {symbolType}.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine($"Ошибка: Число слишком большое. Максимум 16 {symbolType}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Неожиданная ошибка: {ex.Message}");
                }
            }
        }

        static string GeneratePassword(int letterCount, int specialCharCount, int numberCount)
        {
            StringBuilder password = new StringBuilder();

            // Генерация букв (случайное распределение между верхним и нижним регистром)
            for (int i = 0; i < letterCount; i++)
            {
                if (random.Next(2) == 0) // 50% вероятность для каждого регистра
                {
                    password.Append(LowercaseLetters[random.Next(LowercaseLetters.Length)]);
                }
                else
                {
                    password.Append(UppercaseLetters[random.Next(UppercaseLetters.Length)]);
                }
            }

            // Генерация спецсимволов
            for (int i = 0; i < specialCharCount; i++)
            {
                password.Append(SpecialCharacters[random.Next(SpecialCharacters.Length)]);
            }

            // Генерация чисел
            for (int i = 0; i < numberCount; i++)
            {
                password.Append(Numbers[random.Next(Numbers.Length)]);
            }

            // Перемешиваем символы для большей случайности
            return ShuffleString(password.ToString());
        }

        static string ShuffleString(string input)
        {
            char[] characters = input.ToCharArray();

            // Алгоритм Фишера-Йетса для перемешивания
            for (int i = characters.Length - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                // Обмен значениями
                (characters[i], characters[j]) = (characters[j], characters[i]);
            }

            return new string(characters);
        }

        static void DisplayPasswordStrength(string password)
        {
            Console.WriteLine();
            Console.WriteLine("Анализ надежности пароля:");

            bool hasLower = password.Any(char.IsLower);
            bool hasUpper = password.Any(char.IsUpper);
            bool hasDigit = password.Any(char.IsDigit);
            bool hasSpecial = password.Any(ch => !char.IsLetterOrDigit(ch));

            int strengthScore = 0;

            if (hasLower) strengthScore++;
            if (hasUpper) strengthScore++;
            if (hasDigit) strengthScore++;
            if (hasSpecial) strengthScore++;
            if (password.Length >= 12) strengthScore++;
            if (password.Length >= 16) strengthScore++;

            string strengthLevel = strengthScore switch
            {
                0 or 1 => "Очень слабый",
                2 => "Слабый",
                3 => "Средний",
                4 => "Хороший",
                5 => "Сильный",
                _ => "☻ Очень сильный"
            };

            Console.WriteLine($"Уровень надежности: {strengthLevel}");

            if (!hasLower)
                Console.WriteLine("Рекомендация: Добавьте строчные буквы");
            if (!hasUpper)
                Console.WriteLine("Рекомендация: Добавьте заглавные буквы");
            if (!hasDigit)
                Console.WriteLine("Рекомендация: Добавьте цифры");
            if (!hasSpecial)
                Console.WriteLine("Рекомендация: Добавьте спецсимволы");
            if (password.Length < 8)
                Console.WriteLine("Рекомендация: Увеличьте длину пароля до 8+ символов");
        }
    }
}