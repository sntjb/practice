﻿using System;
using System.IO;
using System.Text;

class Program
{
    static void Main()
    {
        Console.Write("Введите путь к файлу: ");
        string filePath = Console.ReadLine();

        Console.Write("Введите ключ: ");
        string key = Console.ReadLine();

        if (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(key))
        {
            Console.WriteLine("Ошибка: путь к файлу и ключ не могут быть пустыми.");
            return;
        }

        if (!File.Exists(filePath))
        {
            Console.WriteLine("Ошибка: файл не существует.");
            return;
        }

        try
        {
            byte[] fileBytes = File.ReadAllBytes(filePath);
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            byte[] resultBytes = new byte[fileBytes.Length];

            for (int i = 0; i < fileBytes.Length; i++)
            {
                resultBytes[i] = (byte)(fileBytes[i] ^ keyBytes[i % keyBytes.Length]);
            }

            string resultPath = filePath + ".xor";
            File.WriteAllBytes(resultPath, resultBytes);

            Console.WriteLine($"Готово. Результат: {resultPath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
}