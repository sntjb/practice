﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hexread
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите путь до файла: ");
            string path = Console.ReadLine();
            if (string.IsNullOrEmpty(path))
            {
                Console.WriteLine("Ошибка, путь не может быть пустым!");
                return;
            }
            var keyValues = new Dictionary<string, string>
            {
                { "4D5A", "Windows Executable (EXE/DLL) — MZ" },
                { "7F454C46", "ELF Executable (Linux)" },
                { "25504446", "PDF Document" },
                { "89504E470D0A1A0A", "PNG Image" },
                { "FFD8FF", "JPEG Image" },
                { "47494638", "GIF Image" },
                { "494433", "MP3 Audio (ID3 tag)" },
                { "4F676753", "OGG Audio" },
                { "52494646", "RIFF (AVI/WAV/WEBP container)" },
                { "504B0304", "ZIP Archive / DOCX / XLSX / JAR" },
                { "526172211A0700", "RAR Archive (RAR4)" },
                { "526172211A070100", "RAR Archive (RAR5)" },
                { "1F8B", "GZIP Compressed" },
                { "425A68", "BZIP2 Compressed" },
                { "377ABCAF271C", "7-Zip Archive" },
                { "D0CF11E0A1B11AE1", "MS Office (OLE2) — DOC/XLS (old)" },
                { "CAFEBABE", "Java Class File" },
                { "FEEDFACE", "Mach-O Executable (32-bit)" },
                { "FEEDFACF", "Mach-O Executable (64-bit)" },
                { "2321", "Unix Script (Shebang #!)" },
            };
            int n = 0;
            FileStream fileStream = new FileStream(path, FileMode.Open);
            byte[] readBytes = new byte[16];
            fileStream.Read(readBytes, 0, 16);
            string hex = BitConverter.ToString(readBytes).Replace("-", string.Empty).ToUpper();
            foreach (var key in keyValues)
            {
                if (hex.StartsWith(key.Key, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine(key.Value);
                    n++;
                }


            }

            if (n == 0)
            {
                Console.WriteLine("Тип файла неизвестен");
            }
            Console.ReadKey();
        }
    }
}
