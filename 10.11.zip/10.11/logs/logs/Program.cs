﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace logs
{
    internal class Program
    {
        static void Main(string[] args)

        {
            string evtxFilePath = @"C:\Users\nayde\Desktop\10.11\jurnal_security.evtx"; // Replace with your EVTX file path
            string savePath = @"C:\Users\nayde\Desktop\10.11\text.txt";
            string query = "*[System[EventID=4688]]"; // Example: EventID 4688 (creating new process)
            EventLogQuery eventQuery = new EventLogQuery(evtxFilePath, PathType.FilePath, query);
            string name = "dryabyshkin_adm";
            string text;
            using (EventLogReader reader = new EventLogReader(eventQuery))
            {
                EventRecord eventRecord;
                while ((eventRecord = reader.ReadEvent()) != null)
                {
                    using (eventRecord)
                    {
                        if (eventRecord.FormatDescription().Contains("dryabyshkin_adm"))
                        { 
                        Console.WriteLine($"TimeCreated: {eventRecord.TimeCreated}");
                        Console.WriteLine($"Level: {eventRecord.LevelDisplayName}");
                        Console.WriteLine($"Event ID: {eventRecord.Id}");
                        Console.WriteLine($"Message: {eventRecord.FormatDescription()}");
                        Console.WriteLine("------------------------------------");
                            text = $"TimeCreated: {eventRecord.TimeCreated}" + "\n" + $"Level: {eventRecord.LevelDisplayName}" + "\n" + $"Event ID: {eventRecord.Id}" + "\n" + $"Message: {eventRecord.FormatDescription()}" + "\n" + "------------------------------------" + "\n";
                            File.AppendAllText(savePath, text);
                        }
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
