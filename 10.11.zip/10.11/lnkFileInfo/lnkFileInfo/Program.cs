﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lnkFileInfo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            string savePath = @"C:\Users\nayde\Desktop\день первый\file.txt";
            File.WriteAllText(savePath, "");
            string text;
            Console.WriteLine(@"Введите путь к папке. Пример: C:\\Users\\nayde\\Desktop\");
            string path = Console.ReadLine();
            string[] file = Directory.GetFiles(path, "*.lnk");
            foreach (string currentFile in file)
            {
                FileInfo fileInfo = new FileInfo(currentFile);
                InfoClass shortcut = new InfoClass()
                {
                    Name = Path.GetFileName(currentFile),
                    Path = currentFile,
                    CreationDate = fileInfo.CreationTime,
                    Size = fileInfo.Length
                };
                Console.WriteLine($"Имя: {shortcut.Name}\n Путь: {shortcut.Path}\n Дата создания: {shortcut.CreationDate.ToShortDateString()}\n Размер: {shortcut.Size} байт" + "\n-------------------------------------------");
                File.AppendAllText(savePath, $"Имя: {shortcut.Name}\n Путь: {shortcut.Path}\n Дата создания: {shortcut.CreationDate.ToShortDateString()}\n Размер: {shortcut.Size} байт" + "\n-------------------------------------------");
            }
            Console.ReadLine();
        }
    }
    public class InfoClass
    {
        public string Name { get; set; }
        public string Path { get; set; }
        public DateTime CreationDate { get; set; }
        public long Size { get; set; }
    }
}
